from setuptools import setup

setup(name='distributions_rajeev',
      version='0.1',
      description='Gaussian + Binomial distributions',
      packages=['distributions_rajeev'],
      author='Rajeev Jhaj',
      author_email='me@rajeevj.co.uk',
      zip_safe=False)
